Compiled and ran with java 1.8 and akka 2.1.4.
Included jars in lib: akka-actor.jar, config.jar, and scala-library.jar when building this project.