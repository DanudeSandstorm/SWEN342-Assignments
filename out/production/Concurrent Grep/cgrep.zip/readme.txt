Building/Running can be done using provided
shell scripts from the root directory.

Building:
./build.sh

Running:
./run.sh pattern [standard input | files...]
