cd bin
java src.CGrep $*
