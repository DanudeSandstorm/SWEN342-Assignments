javac -d bin/ src/*.java
